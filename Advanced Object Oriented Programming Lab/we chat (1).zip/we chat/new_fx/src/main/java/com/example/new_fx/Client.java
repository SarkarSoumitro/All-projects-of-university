package com.example.new_fx;

import java.io.*;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.concurrent.Callable;

public class Client implements Runnable {
    String clientName;


    BufferedReader reader;
    BufferedWriter writer;

    final static ArrayList<Client> clients = new ArrayList<>();


    Client(Socket sc) {

        try {
            // this.clientName=clientName;

            OutputStreamWriter o = new OutputStreamWriter(sc.getOutputStream());
            writer = new BufferedWriter(o);

            InputStreamReader isr = new InputStreamReader(sc.getInputStream());
            reader = new BufferedReader(isr);

            clientName = reader.readLine();
            clients.add(this);
            System.out.println("Client " + clientName + " is connected");

            //
            File file = new File("Connection history.text");
            FileWriter fr = new FileWriter(file,true);
            BufferedWriter br = new BufferedWriter(fr);
            br.write("******Your friend " + clientName + " is connected*********"+"\n");
            br.close();
            fr.close();



        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void run() {
        while (true) {
            try {
                String data = reader.readLine();
                data = clientName + " : " + data + "\n";

                File file = new File("CHATS.text");
                FileWriter fr = new FileWriter(file,true);
                BufferedWriter br = new BufferedWriter(fr);
                br.write(data+"\n");
                br.close();
                fr.close();

                synchronized (clients) {
                    for (Client client : clients) {

                        client.writer.write(data);
                        client.writer.flush();
                    }
                }


            } catch (SocketException E) {
                break;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
