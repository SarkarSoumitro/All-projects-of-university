package com.example.new_fx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;


import java.io.*;
import java.net.Socket;
import java.net.SocketException;
import java.util.Objects;
import java.util.Scanner;

public class HelloController {

    private Scene scene;
    private Stage stage;
    private Parent root;
    public String NAME;
     @FXML
    private TextField L_TFT1,L_TFT2;
     @FXML
     private Label not_re;
     @FXML
     private TextArea showArea;
     @FXML
     private TextField inputField;
    boolean isConnected = false;
    BufferedReader reader;
    BufferedWriter writer;
    @FXML
    Button button;


    @FXML
    private TextField TFT1,TFT2,TFT3;


    @FXML
    protected void RESISTER_ONCLICK(ActionEvent event) throws IOException {
         NAME=TFT1.getText();
        String PASS=TFT2.getText();
        String NUM=TFT3.getText();

            File file = new File("ddd.text");
            FileWriter fr = new FileWriter(file, true);
            BufferedWriter br = new BufferedWriter(fr);
            br.write(NAME + " " + PASS + " " + NUM + "\n");

            br.close();
            fr.close();


            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("REGISTER.fxml")));

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();




    }
    @FXML
    protected void LOGIN_ONCLICK(ActionEvent event) throws IOException {
           String NaME=L_TFT1.getText();
           String PaSS=L_TFT2.getText();


        System.out.println(NAME);

        File F=new File("ddd.text");





        try{
            Scanner S= new Scanner(F);

            while(S.hasNextLine()){
                String line =S.nextLine();

                String [] V=line.split(" ");

                if ( (NaME.equalsIgnoreCase(V[0])) && (PaSS.equals(V[1])))  {
                    System.out.println(V[0]);



                    FXMLLoader loader=new FXMLLoader(getClass().getResource("LAST.fxml"));
                    root =loader.load();
                    chatController c =loader.getController();
                    c.displayname( NaME);



                    Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

                    scene =new Scene(root);
                    stage.setScene(scene);
                    stage.show();



                }
                else {
                    not_re.setText("You are not registered !");

                }


            }
        } catch (Exception e){
            System.out.println(e);
        }


    }


    @FXML
    protected void to_resister(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("hello-view.fxml")));

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        scene =new Scene(root);
        stage.setScene(scene);
        stage.show();


    }


    @FXML
    protected void to_login(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("REGISTER.fxml")));

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        scene =new Scene(root);
        stage.setScene(scene);
        stage.show();



    }





}