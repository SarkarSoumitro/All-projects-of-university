package com.example.new_fx;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;

public class MyServer {
    public static void main(String[] args) {
        try {
            System.out.println("Server is waiting for client .");
            ServerSocket serverSocket = new ServerSocket(33333);
            while (true) {
                Socket sc = serverSocket.accept();
                Client client = new Client(sc);
                Thread t = new Thread(client);
                t.start();
            }



        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
