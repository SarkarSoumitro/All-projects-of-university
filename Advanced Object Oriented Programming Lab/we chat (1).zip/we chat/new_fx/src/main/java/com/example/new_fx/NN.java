package com.example.new_fx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

import static javafx.fxml.FXMLLoader.load;

public class NN {

    private Scene scene;
    private Stage stage;
    private Parent root;

    @FXML
    private BorderPane borderPane;


    @FXML
    private void btnDashboard(ActionEvent event) throws IOException {

        AnchorPane view = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("n3")));
        borderPane.setCenter(view);
    }
    @FXML
    private void btnSetting(ActionEvent event) throws IOException {
        AnchorPane view = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("n4")));
        borderPane.setCenter(view);


    }

    @FXML
    private void hangman(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("hangman.fxml")));

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        scene =new Scene(root);
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    private void TIC (ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Tictac.fxml")));

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        scene =new Scene(root);
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    private void Brick (ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("brick.fxml")));

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        scene =new Scene(root);
        stage.setScene(scene);
        stage.show();

    }



}
