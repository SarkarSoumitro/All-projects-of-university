package com.example.new_fx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.*;
import java.net.Socket;
import java.net.SocketException;
import java.util.Objects;
import java.util.Scanner;

public class chatController {
    private Scene scene;
    private Stage stage;
    private Parent root;

    @FXML
    private TextArea n;
    @FXML
    private Label C_NAME;

    @FXML
    private TextArea showArea;
    @FXML
    private TextField inputField;
    boolean isConnected = false;
    BufferedReader reader;
    BufferedWriter writer;
    @FXML
    Button button;
    String NAME;


    public void displayname(String u){
       NAME=u;
    }


    @FXML
    protected void buttonPressed()  {

        if (!isConnected) {
            System.out.println(NAME);
//            String inputName = inputField.getText();
//            inputField.clear();
            //System.out.println(text);

//            if (NAME == null || NAME.length() == 0) {
//                showArea.appendText("Enter a valid name !\n");
//                return;
//            }

            try {
                Socket sc = new Socket("localhost", 33333);

                OutputStreamWriter o = new OutputStreamWriter(sc.getOutputStream());
                writer = new BufferedWriter(o);
                writer.write(NAME + "\n");
                writer.flush();

                InputStreamReader isr = new InputStreamReader(sc.getInputStream());
                reader = new BufferedReader(isr);
                //Anonymous inner class
                Thread serverListener = new Thread() {
                    @Override
                    public void run() {
                        while (true) {
                            try {
                                String data = reader.readLine() + "\n";
                               // showArea.appendText(data);



                                showArea.appendText(data);

                            } catch (SocketException w) {
                                break;
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                };
                serverListener.start();
                C_NAME.setText("Hey "+ NAME +"!" );


                showArea.appendText("Connection Established\n");
                button.setText("Send");
                inputField.setText(null);
                inputField.setPromptText("WRITE A MASSAGE");
                isConnected = true;


            } catch (IOException e) {
                e.fillInStackTrace();
            }

        }

        else {
            try {
                String msg = inputField.getText();
                //System.out.println(text);
                inputField.clear();

                if (msg == null || msg.length() == 0) {
                   // showArea.appendText("Enter a valid name !\n");
                    return;
                }
                writer.write(msg + "\n");
                writer.flush();
            } catch (IOException E) {
                E.printStackTrace();
            }
        }

    }


    @FXML
    protected void game (ActionEvent event) throws IOException {


        FXMLLoader fxmlLoader =new FXMLLoader(getClass().getResource("nn.fxml"));
        Parent load = (Parent) fxmlLoader.load();
        Stage stage=new Stage();

        stage.setTitle("");
        stage.setScene(new Scene(load));
        stage.show();


    }


    @FXML
    protected void OLD_M (ActionEvent event) throws IOException {
        File F=new File("CHATS.text");

        try {
            Scanner S = new Scanner(F);

            while (S.hasNextLine()) {
                String line = S.nextLine();
                showArea.appendText(line+"\n");
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }


    @FXML
    protected void OLD_C (ActionEvent event) throws IOException {
        File F=new File("Connection history.text");

        try {
            Scanner S = new Scanner(F);

            while (S.hasNextLine()) {
                String line = S.nextLine();
                showArea.appendText(line+"\n");
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @FXML
    protected void LOGOUT(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("END.fxml")));

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        scene =new Scene(root);
        stage.setScene(scene);
        stage.show();



    }

}
