module com.example.new_fx {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.new_fx to javafx.fxml;
    exports com.example.new_fx;
}